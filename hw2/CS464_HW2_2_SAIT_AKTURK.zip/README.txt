-The tester should install this libraries
-pip3 install opencv
-pip3 install opencv-contrib
-pip3 install sklearn==0.19.1( I strongly suggest to install this version for PCA issue)
-pip3 install pandas
-pip3 install numpy 
-pip3 install matplotlib

!!!The tester should use at least 4GB RAM system. Since I am loading all data once.!!!

-To run all question just run:
*"python3 CS464_HW2_2_SAIT_AKTURK.py"
-To run only first question:
*"python3 CS464_HW2_2_SAIT_AKTURK.py 1"
-To run only second question:
*"python3 CS464_HW2_2_SAIT_AKTURK.py 2"
-To run only third question:
*"python3 CS464_HW2_2_SAIT_AKTURK.py 3"
-To run only fourth question:
*"python3 CS464_HW2_2_SAIT_AKTURK.py 4"